#include <stdlib.h>
#include "my_RCC_and_GPIO.h"
#include "spiHandler.h"
#include "my_Systick.h"
#include "my_exti.h"


// -------------------------------
// 				WORK IN PROGRESS
// Drivers may not behave as expected
// -------------------------------


// uint32_t kontUSART3Transmitter = 0;	//USART6 transmitter character count
// uint8_t bufferUSART3receiver[8];		//buffer for receiving from the USART6 RX register
// uint8_t bufferUSART3transmitter[8];		//buffer for sending to the USART6 TX register
// uint32_t kontUSART3Receiver = 0;		//USART6 receiver character count
// uint32_t byteKontUSART3 = 0;			//how many bytes must be read from USART6 so the data can be send to USART3



void SPI3_init(void){
    
    /***************  PASOS A DAR
        1. Activar UART CLOCK y GPIO CLOCK
        2. Configurar los PINS como Alternate Functions
        3. Activar USART escribiendo en el bit UE en USART_CR1 un 1
        4. Programar el bit M de USART para definir los bits(word lenght)
        5. Seleccionar el baud rate deseado en USART_BRR
        6. Activar el transmisor/receptor usando los registros TE y RE de USART_CR1
    ****************/
    
    //1. Activar UART CLOCK
	
		RCC_APB1PeriphClockCmd(15);
    //2. Activar GPIO y Configurar los PINS como Alternate Functions
    
		SPI_configure(GPIO_A, GPIO_PIN_0, GPIO_PIN_4, GPIO_PIN_5, 6); //gpio, pin sck, pin sdo, pin cs, pin af

    //3. Activar USART escribiendo en el bit UE en USART_CR1 un 1
    
    SPI_enable(SPI3, SPI_ENABLE);
		SPI_bidimode(SPI3, SPI_2LINE_UNI);
		

    //4. Programar el bit M de USART para definir los bits(word lenght)
    
    //SPI_setDataStopBits(SPI3, UART_8_DATA_BITS, UART_1_STOP_BIT);
    
    //5. Seleccionar el baud rate deseado en USART_BRR
    
    SPI_setBaudRate(SPI3, SPI_BR_fPCLKdiv8); //16mh/8 = 2mh --> pmodALS requires 1mh to 4mh.
		

    //6. Activar el transmisor/receptor usando los registros TE y RE de USART_CR1
		
		SPI_receive_only(SPI3, SPI_OUTPUT_DISABLED);

        
    //7. Activamos la posibilidad de interrumpir 
    
   // RXNE_setStateInterrupt(SPI3, ENABLE);
    
}

void SPI_configure(GPIO_X GPIO, GPIO_PIN_X pinSCK, GPIO_PIN_X pinSDO, GPIO_PIN_X pinCS, uint32_t pinAF)	//enable the clocks of the GPIOs that contain the RX and TX pins, configure them in alternate function at very high speed, do a generic conf of USART6 and enable the NVIC interrrupt
{
	
	GPIO_TypeDef* gpioType=GpioType(GPIO);

	RCC_AHB1PeriphClockCmd(GPIO);
	
	GPIO_initPinMode(gpioType, pinSCK, MODE_AF); //SPI sck
	GPIO_initPinMode(gpioType, pinSDO, MODE_AF); // sdo
	GPIO_initPinMode(gpioType, pinCS, MODE_AF); //cs
	
	GPIO_setPinSpeed(gpioType, pinSCK, VERY_HIGH_SPEED);
	GPIO_setPinSpeed(gpioType, pinSDO, VERY_HIGH_SPEED);
	GPIO_setPinSpeed(gpioType, pinCS, VERY_HIGH_SPEED);
	
	GPIO_setAFReg(gpioType, pinSCK, pinAF); // referenceManual PAG 272 select an af
	GPIO_setAFReg(gpioType, pinSDO, pinAF); // referenceManual PAG 272 select an af
	GPIO_setAFReg(gpioType, pinCS, pinAF); // se usa para asignar el usart al mux, af7 = usart1-3, af8= usart4-6
	
	GPIO_setPinValue(gpioType, pinCS, 0);
	NVIC_enable(71);
}


char * SPI_getString(void){
   
	static char cadena[200]; // array fijo para que no se llene la memoria
    //recibir una cadena de caracteres
	
    int i = 0;
    while(i < 200){
        cadena[i] = SPI_getChar(SPI3);
        if(cadena[i] == '\r'){
            cadena[i] = '\0';

            break;
        }
        i++;
    }
		return cadena;
	}

uint8_t SPI_getChar (SPI_TypeDef* SPI){
            /*********** STEPS FOLLOWED *************
    
    1. Esperamos a que el bit RXNE se setee. Esto indica que la informacion se ha recibido y que se puede leer
    2. Leemos la informacion usando USART_DR.     Esto tambien limpia el bit RXNE
    
    ****************************************/

    uint8_t temp;
        
    while (!SPI_SR_RXNE);  // esperamos a que el bit RXNE se  --> se ha recibido la informaci?n
    temp = (uint8_t) SPI->DR;  // leemos la informacion y limpiamos RXNE
    return temp;
}

// ---------------------

void SPI_enable(SPI_TypeDef* SPI, SPI_ENABLE_DISABLE enable)
{
	if (enable)
	{
		SPI->CR1 |= (1 << 6); // SPE REGISTER pag 921 ref. manual
	}
	else
	{
		SPI->CR1 &= ~(1u << 6);
	}
}

void SPI_setBaudRate(SPI_TypeDef* SPI, SPI_BAUD_RATE desiredBaudRate)
{
		SPI->CR1 &= ~(0x03u << 3); 
	SPI->CR1 = ((unsigned)desiredBaudRate << 3); //pag 920 ref manual
}

void SPI_bidimode(SPI_TypeDef* SPI, SPI_BIDIMODE bidi)
{
	if (bidi)
	{
		SPI->CR1 |= (1 << 15); // 
	}
	else
	{
		SPI->CR1 &= ~(1u << 15);
	}
}
void SPI_output_mode(SPI_TypeDef* SPI, SPI_OUTPUT_MODE enable)
{
	if (enable)
	{
		SPI->CR1 |= (1 << 14); // 
	}
	else
	{
		SPI->CR1 &= ~(1u << 14);
	}
	
}

void SPI_receive_only(SPI_TypeDef* SPI, SPI_RXONLY_MODE mode)
{
	if (mode)
	{
		SPI->CR1 |= (1 << 10); // 
	}
	else
	{
		SPI->CR1 &= ~(1u << 10);
	}
	
}

