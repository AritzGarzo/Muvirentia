#ifndef OUR_UART_H
#define OUR_UART_H

#include <stdint.h>
#include "my_RCC_and_GPIO.h"

#include <stdio.h>

#define     __OM     volatile
#define     __IOM    volatile 
	
#define OUR_USART1 ((OUR_USART_TypeDef*)0x40011000U)
#define OUR_USART2 ((OUR_USART_TypeDef*)0x40004400U)
#define OUR_USART3 ((OUR_USART_TypeDef*)0x40004800U)
#define OUR_USART6 ((OUR_USART_TypeDef*)0x40011400U)

#define OUR_UART_SR_RXNE (0x1UL << 5)
#define OUR_USART3_IRQn 39

#define OUR_NVIC ((OUR_NVIC_Type*)0xE000E100U)

#define ENABLE 1
#define DISABLE 0

typedef struct{
  __IO uint32_t SR;         /*!< USART Status register,                   Address offset: 0x00 */
  __IO uint32_t DR;         /*!< USART Data register,                     Address offset: 0x04 */
  __IO uint32_t BRR;        /*!< USART Baud rate register,                Address offset: 0x08 */
  __IO uint32_t CR1;        /*!< USART Control register 1,                Address offset: 0x0C */
  __IO uint32_t CR2;        /*!< USART Control register 2,                Address offset: 0x10 */
  __IO uint32_t CR3;        /*!< USART Control register 3,                Address offset: 0x14 */
  __IO uint32_t GTPR;       /*!< USART Guard time and prescaler register, Address offset: 0x18 */
} OUR_USART_TypeDef;

typedef struct{
  __IOM uint32_t ISER[8U];               /*!< Offset: 0x000 (R/W)  Interrupt Set Enable Register */
        uint32_t RESERVED0[24U];
  __IOM uint32_t ICER[8U];               /*!< Offset: 0x080 (R/W)  Interrupt Clear Enable Register */
        uint32_t RESERVED1[24U];
  __IOM uint32_t ISPR[8U];               /*!< Offset: 0x100 (R/W)  Interrupt Set Pending Register */
        uint32_t RESERVED2[24U];
  __IOM uint32_t ICPR[8U];               /*!< Offset: 0x180 (R/W)  Interrupt Clear Pending Register */
        uint32_t RESERVED3[24U];
  __IOM uint32_t IABR[8U];               /*!< Offset: 0x200 (R/W)  Interrupt Active bit Register */
        uint32_t RESERVED4[56U];
  __IOM uint8_t  IP[240U];               /*!< Offset: 0x300 (R/W)  Interrupt Priority Register (8Bit wide) */
        uint32_t RESERVED5[644U];
  __OM  uint32_t STIR;                   /*!< Offset: 0xE00 ( /W)  Software Trigger Interrupt Register */
}  OUR_NVIC_Type;

typedef enum{ 
	BAUD_RATE_9600   = 9600, /*!< UART BAUDRATE 9600 */
	BAUD_RATE_14400   = 14400, /*!< UART BAUDRATE 14400 */
	BAUD_RATE_115200   = 115200, /*!< UART BAUDRATE 115200 */
}UART_BAUD_RATE;

typedef enum{ 
  UART_1_STOP_BIT   = 0x00, /*!< UART 1 STOP BIT */
	UART_0_5_STOP_BIT   = 0x01, /*!< UART 0.5 STOP BIT */
	UART_2_STOP_BIT   = 0x10, /*!< UART 2 STOP BIT */
	UART_1_5_STOP_BIT   = 0x11, /*!< UART 1.5 STOP BIT */

}UART_STOP_BITS;

typedef enum{ 
  UART_8_DATA_BITS   = 0x00, /*!< UART 8 DATA BIT */
	UART_9_DATA_BITS  = 0x01, /*!< UART 9 DATA BIT */

}UART_DATA_BITS;

typedef enum{ 
  UART_PARITY_EVEN_0   = 0x00, /*!< UART PARITY 0 */
	UART_PARITY_ODD_1  = 0x01, /*!< UART PARITY 1 */

}UART_PARITY;

typedef enum{ 
  UART_PARITY_CONTROL_DISABLE   = 0x00, /*!< UART PARITY DISABLE */
	UART_PARITY_CONTROL_ENABLE  = 0x01, /*!< UART PARITY ENABLE */

}UART_PARITY_CONTROL;

typedef enum{ 
  UART_ENABLE   = 1, /*!< ENABLE */
	UART_DISABLE = 0, /*!< DISABLE */

}UART_ENABLE_DISABLE;



//void UART_SendChar(OUR_USART_TypeDef* usart, uint8_t c);
//void UART_SendString(OUR_USART_TypeDef* usart, char* string);
//void printUint32t(OUR_USART_TypeDef* usart, uint32_t val);

//int recibir(void);


//uint8_t UART_getChar (OUR_USART_TypeDef* usart);
//void USART3_ourHandler(void);




void USART_enable(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable);
void USART_enableReciver(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable);
void USART_enableTransmitter(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable);
//void USART_enableInterruptions(OUR_USART_TypeDef* usart, int n);

void USART_setDataStopBits(OUR_USART_TypeDef* usart, UART_DATA_BITS dataBits, UART_STOP_BITS stopBits);
void USART_setBaudRate(OUR_USART_TypeDef* usart, UART_BAUD_RATE baud);
void USART_setParity(OUR_USART_TypeDef* usart, UART_PARITY parity);
void USART_setParityControl(OUR_USART_TypeDef* usart, UART_PARITY_CONTROL parity);	


void RXNE_setStateInterrupt(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable);
void TXE_setStateInterrupt(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable);
void TC_setStateInterrupt(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable);

void DR_setRegister(OUR_USART_TypeDef* usart, uint8_t enable);
uint8_t DR_getRegisterValue(OUR_USART_TypeDef* usart);
uint32_t SR_getRegisterValue(OUR_USART_TypeDef* usart);

void TC_clearInterrupt(OUR_USART_TypeDef* usart);




#endif
