#ifndef USART_HANDLING_H
#define USART_HANDLING_H
#include <stdint.h>
#include <stm32f407xx.h>
#include "usartConfig.h"
#include "my_RCC_and_GPIO.h"

void USART3_init(void); //configura los registers
void USART_configure(GPIO_X GPIO, GPIO_PIN_X pinTX, GPIO_PIN_X pinRX, uint32_t pinAF);//enable los clocks de los gpio
void USART_sendChar(OUR_USART_TypeDef* usart, uint8_t c); //manda un caracter
void USART_sendString(OUR_USART_TypeDef* usart, char* string);		//this function copies the string introduced to the USART6 transmitter buffer, enables the TXE interrupt and sends the first character
char * USART_getString(void);
uint8_t USART_getChar (OUR_USART_TypeDef* usart);
//void USART_RX3Handler(void); // recibe lo del DR, lo manda cuando esta lleno
//void USART_TX3Handler(void); // limpia el interrupt de TC, transmite hasta el final del buffer
//void USART_T3Handler(void); //funcion que se llama si se manda o recibe datos


#endif
