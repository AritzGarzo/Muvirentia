#include "my_RCC_and_GPIO.h"
#include "my_Systick.h"
#include "my_exti.h"
#include "usartConfig.h"
#include "usartHandler.h"
#include "string.h"

#define LED_ENABLE 1


static volatile int end=0;

void val_config(void);
void EXTI0_IRQHandler(void);


int main(void)
{
	char * info={"t20 h60 l200."};
	
	
	getSysClockFreq();
	USART3_init();
	val_config(); //	config of led simulation
	
	
	while(end==0)
	{
		sleep(10);
		uint8_t mode = USART_getChar(OUR_USART3);
		
		// SPI and I2C, and other sensor data would be picked up here
	
		if	(mode=='r') USART_sendString(OUR_USART3, info); //sends temp, humidity and light when other side decides
		
	
		if	(mode=='1') //open and close received from the graphics enviroment
		{
			GPIO_setPinValue(GPIOF,GPIO_PIN_6,LED_ENABLE);
			GPIO_setPinValue(GPIOF,GPIO_PIN_7,!LED_ENABLE);
		}
		else if(mode=='0')
		{
			GPIO_setPinValue(GPIOF,GPIO_PIN_6,!LED_ENABLE);
			GPIO_setPinValue(GPIOF,GPIO_PIN_7,LED_ENABLE);
		}


	}
}



	
	void val_config(void){
	RCC_AHB1PeriphClockCmd(GPIO_F);
	GPIO_initPinMode(GPIOF,GPIO_PIN_6,MODE_OUT);
	GPIO_initPinMode(GPIOF,GPIO_PIN_7,MODE_OUT);

	enable_X_interruptOnExtiX_WhenRising(0,'a',rising);
	}




void EXTI0_IRQHandler(void){ //wkup, ends the program on this side
	EXTI->PR = (1<< 0);
	end=1;
}



