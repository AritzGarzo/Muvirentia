//Ainhoa Alonso Antelo
#ifndef _MY_GPIO_H_
#define	_MY_GPIO_H_

#include <stdint.h>
#include "stm32f4xx.h"

//crea un enum de gpioA al gpioF

typedef enum {
    GPIO_A=0,
    GPIO_B=1,
    GPIO_C=2,
    GPIO_D=3,
    GPIO_E=4,
    GPIO_F=5,
		GPIO_G=6,
		GPIO_H=7,
		GPIO_I=8
} GPIO_X;


typedef enum {
  GPIO_PIN_0=0,
  GPIO_PIN_1=1,
  GPIO_PIN_2=2,
  GPIO_PIN_3=3,
  GPIO_PIN_4=4,
  GPIO_PIN_5=5,
	GPIO_PIN_6=6,
	GPIO_PIN_7=7,
	GPIO_PIN_8=8,
  GPIO_PIN_9=9,
  GPIO_PIN_10=10,
  GPIO_PIN_11=11,
  GPIO_PIN_12=12,
  GPIO_PIN_13=13,
  GPIO_PIN_14=14,
  GPIO_PIN_15=15
} GPIO_PIN_X;

typedef enum{
  MODE_IN = 0,
  MODE_OUT = 1,
  MODE_AF = 2,
  MODE_AN = 3
  }PIN_MODE;
  
  typedef enum {
	  LOW_SPEED = 0,
	  MEDIUM_SPEED =1,
	  HIGH_SPEED=2,
	  VERY_HIGH_SPEED=3
  }PIN_SPEED;

	//GPIO_Type
GPIO_TypeDef * GpioType(GPIO_X gpio); //devuelve el gpio del gpio seleccionado
	

// Funtzioen prototipoak

// Aktibatu GPIO periferikoa
void RCC_AHB1PeriphClockCmd(uint32_t periph); //Para activar GPIO
void RCC_APB1PeriphClockCmd(uint32_t periph);
	
// Konfiguratu GPIO periferikoko pin jakin bat
// sarrera/irteera/analogiko/alternatibo gisa
void	GPIO_initPinMode(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin, uint32_t mode);

// Irakurri GPIO periferiko bateko pin bat
uint32_t	GPIO_getPinValue(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin);

// Idatzi balioa GPIO periferiko baten pin batean
void	GPIO_setPinValue(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin, uint32_t balioa);

// Aldatu GPIO periferiko baten pinaren egoera
void	GPIO_togglePinValue(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin);

// Aldatu pinaren abiadura
void GPIO_setPinSpeed(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin, uint32_t abiadura);

//Ezarri pin-a altern function regirterra
void GPIO_setAFReg(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin, uint32_t af);

#endif//_MY_GPIO_H_
