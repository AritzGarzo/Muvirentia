//Ainhoa Alonso Antelo
#ifndef _MY_Systick_H_
#define _MY_Systick_H_

#include <stdint.h>
#include "stm32f4xx.h"
//#define CPU_FREQ 16000000 /* 16MHz */

void sleep(uint32_t milisegundos);

void enableExternalClock(void);

void disableExternalClock(void);
	
void cambiarConfiguracionReloj(void);

uint32_t getSysClockFreq(void);

#endif
