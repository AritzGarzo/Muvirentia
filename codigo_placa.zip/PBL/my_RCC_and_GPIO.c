//Ainhoa Alonso Antelo
#include <stdint.h>
#include "my_RCC_and_GPIO.h"
#include "stm32f4xx.h"


GPIO_TypeDef * GpioType(GPIO_X gpio)
{

	GPIO_TypeDef * gpio_Type = 0;

	switch (gpio)
	{
	case 0:
		gpio_Type = GPIOA;
		break;
	case 1:
		gpio_Type = GPIOB;
		break;
	case 2:
		gpio_Type = GPIOC;
		break;
	case 3:
		gpio_Type = GPIOD;
		break;
	case 4:
		gpio_Type = GPIOE;
		break;
	case 5:
		gpio_Type = GPIOF;
		break;
	case 6:
		gpio_Type = GPIOG;
		break;
	case 7:
		gpio_Type = GPIOH;
		break;
	case 8:
		gpio_Type = GPIOI;
		break;
	}
	
	return gpio_Type;
}

void RCC_AHB1PeriphClockCmd(uint32_t periph)
{

	RCC->AHB1ENR |= (1 << periph); 

}

void RCC_APB1PeriphClockCmd(uint32_t periph) 
{

	RCC->APB1ENR |= (1 << periph); 
}


void	GPIO_initPinMode(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin, uint32_t mode)
{
	gpio->MODER &= ~ (3u<< (gpio_pin*2)); 
 	gpio->MODER |= mode << (gpio_pin*2);
}


// Irakurri GPIO periferiko bateko pin bat
uint32_t	GPIO_getPinValue(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin)
{

	return (gpio->IDR & (0x01 << gpio_pin));
}

void	GPIO_setPinValue(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin, uint32_t balioa)
{



	if (balioa > 1) // si no es ni 1 ni 0 sale de la funcion.
	{
		return;
	}

	if (balioa == 1)
	{
		gpio->ODR |= (1u << gpio_pin);
	}
	else
	{
		gpio->ODR  &= ~(1u << gpio_pin);
	}
}

void	GPIO_togglePinValue(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin)
{

	
	gpio->ODR ^= (1u << gpio_pin);
}

void GPIO_setPinSpeed(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin, uint32_t abiadura)
{
	gpio->OSPEEDR &= ~ (3u<< (gpio_pin*2)); 
	gpio->OSPEEDR |= abiadura << (gpio_pin*2);
}


void GPIO_setAFReg(GPIO_TypeDef * gpio, GPIO_PIN_X gpio_pin, uint32_t af)
{
	gpio->AFR[gpio_pin/8] &= ~(0xFu << ((gpio_pin % 8)*4));
	gpio->AFR[gpio_pin/8] |= (af << ((gpio_pin%8)*4));
}
