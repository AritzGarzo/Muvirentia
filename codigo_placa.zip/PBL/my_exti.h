//Ainhoa Alonso Antelo
#ifndef _MY_EXTI_H_
#define	_MY_EXTI_H_

#include <stdint.h>
#include "my_RCC_and_GPIO.h"
#include "stm32f4xx.h"

void enable_X_interruptOnExtiX_WhenRising(uint32_t exti,char letra, uint32_t modo);

typedef enum {
    falling = 0,
    rising = 1
} extiMode;

void NVIC_enable(uint32_t x);


/*
typedef enum {
    pA = 0x0000,
    pB = 0x0001,
		pC = 0x0010,
		pD = 0x0011,
    pE = 0x0100,
    pF = 0x0101,
    pG = 0x0110,
    pH = 0x0111
} Pletra;
*/








#endif//_MY_EXTI_H_
