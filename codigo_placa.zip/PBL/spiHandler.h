#ifndef SPI_HANDLING_H
#define SPI_HANDLING_H
#include <stdint.h>
#include <stm32f407xx.h>
#include "my_RCC_and_GPIO.h"

// -------------------------------
// 				WORK IN PROGRESS
// Drivers may not behave as expected
// -------------------------------

typedef enum{
	SPI_ENABLE=1,
	SPI_DISABLE=0
}SPI_ENABLE_DISABLE;


typedef enum{
	SPI_BR_fPCLKdiv2 =0,
	SPI_BR_fPCLKdiv4 =1,
	SPI_BR_fPCLKdiv8 =2,
	SPI_BR_fPCLKdiv16 =3,
	SPI_BR_fPCLKdiv32 =4,
	SPI_BR_fPCLKdiv64 =5,
	SPI_BR_fPCLKdiv128 =6,
	SPI_BR_fPCLKdiv256 =7,
}SPI_BAUD_RATE;

typedef enum{
	SPI_2LINE_UNI = 0,
	SPI_1LINE_BIDI = 1
}SPI_BIDIMODE;

typedef enum{
	SPI_RECEIVEONLY = 0,
	SPI_TRASMITONLY = 1
}SPI_OUTPUT_MODE;

typedef enum{
	SPI_FULLDUPLEX = 0,
	SPI_OUTPUT_DISABLED = 1
}SPI_RXONLY_MODE;


void SPI3_init(void); //configura los registers
void SPI_configure(GPIO_X GPIO, GPIO_PIN_X pinSCK, GPIO_PIN_X pinSDO, GPIO_PIN_X pinCS, uint32_t pinAF);	//enable the clocks of the GPIOs that contain the pins, configure them in alternate function at very high speed, do a generic conf of SPI3 and enable the NVIC interrrupt
void SPI_sendChar(SPI_TypeDef* spi, uint8_t c); //sen a character
void SPI_sendString(SPI_TypeDef* spi, char* string);		
char * SPI_getString(void);
uint8_t SPI_getChar (SPI_TypeDef* spi);

// --------------

void SPI_enable(SPI_TypeDef* SPI, SPI_ENABLE_DISABLE enable);
void SPI_setBaudRate(SPI_TypeDef* SPI, SPI_BAUD_RATE desiredBaudRate);
void SPI_bidimode(SPI_TypeDef* SPI, SPI_BIDIMODE bidi);
void SPI_output_mode(SPI_TypeDef* SPI, SPI_OUTPUT_MODE enable);
void SPI_receive_only(SPI_TypeDef* SPI, SPI_RXONLY_MODE mode);

#endif
