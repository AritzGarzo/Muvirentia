#include "my_RCC_and_GPIO.h"
#include "my_Systick.h"
#include "usartConfig.h"
#include "usartHandler.h"

int main(void)
{
	getSysClockFreq();
	USART3_init();
	


	
	
	
	while(1)
	{
		sleep(1);
		char * cadena	= USART_getString();
		USART_sendString(OUR_USART3, cadena);
	}
	
	
}
