//Ainhoa Alonso Antelo
#include <stdint.h>
#include "my_exti.h"

void enable_X_interruptOnExtiX_WhenRising(uint32_t pin,char letra, uint32_t modo)
{
	//exti 1 - 4
    //SYSCFG gaitu
	RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
	uint32_t exti=0;
	uint32_t posizioa=0;
	uint32_t etenduraZem=0;
	uint32_t iserZem=0;
	
	if(pin <= 3){ // pin de 0 a 3 (como es unsigned no se pone >= 0 porque siempre lo es)
		exti=0;
		posizioa = pin;
	}
	else if(pin >= 4 && pin <= 7 ){
		exti=1;
		posizioa=pin-4;
	}
	else if(pin >= 8 && pin <= 11 ){
		exti=2;
		posizioa=pin-8;
	}
	else if(pin >= 12 && pin <= 15 ){
		exti=3;
		posizioa=pin-12;
	}
	
	//pasa las letras a minuscula
	if(letra >= 'A' && letra <= 'H'){
		letra = letra - 'A' + 'a';
	}
	
	
	
	SYSCFG->EXTICR[exti] &=~(0x0Fu << (4*posizioa));
	SYSCFG->EXTICR[exti] |= (((unsigned)letra - 'a') <<(4*posizioa));
	
	
	
	
	

	
	


  
  //exti konfiguratu

  if(modo==rising){
	EXTI->RTSR |= (0x01<<pin);
	EXTI->FTSR &= ~(0x01<<pin);
 	EXTI->IMR |= (0x01<<pin);
  }else if (modo==falling){
	EXTI->RTSR &= ~(0x01<<pin);
	EXTI->FTSR |= (0x01<<pin);
	EXTI->IMR |= (0x01<<pin);
  }


  //NVIC konfiguratu 5.
	
	if(pin <= 4 ){ // pin de 0 a 4 (como es unsigned no se pone >= 0 porque siempre lo es)
		etenduraZem = pin+6;
	}
	else if(pin >= 5 && pin <= 9 ){
		etenduraZem = 23;
	}
	else if(pin >= 10 && pin <= 15 ){
		etenduraZem = 40;
	}

	while(etenduraZem>=32){
		etenduraZem-=32;
		iserZem++;
	}

	NVIC->ISER[iserZem] |= (0x01<<etenduraZem);


/*
	 ETENDURARI erantzuna konfiguratu 
			Bilatu etendurari erantzuten dion funtzioaren izena.
					- EXTIx_IRQHandler (0,1,2,3,4)
					- EXTI9_5_IRQHandler 
					- EXTI15_10_IRQHandler
			main-ean definitu egin behar duena eta PR erregistroaren flag-a resetatu. 
			PR erregistroa Reference Manualeko 12.3.6 atala. Reseteatzeko PinZenbakiaren bit-a 1era jarri behar da.
			EXTI->PR = (1<< PinZenbakia) [= jarri dugu beste erregistroak ez aldatzeko]
		
	
	
	
*/

}

void NVIC_enable(uint32_t x)
{
	NVIC->ISER[x / 32] |= (0x01 << (x % 32));
}

