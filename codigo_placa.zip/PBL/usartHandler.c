#include <stdlib.h>
#include "my_RCC_and_GPIO.h"
#include "usartConfig.h"
#include "usartHandler.h"
#include "my_Systick.h"
#include "my_exti.h"

// uint32_t kontUSART3Transmitter = 0;	//USART6 transmitter character count
// uint8_t bufferUSART3receiver[8];		//buffer for receiving from the USART6 RX register
// uint8_t bufferUSART3transmitter[8];		//buffer for sending to the USART6 TX register
// uint32_t kontUSART3Receiver = 0;		//USART6 receiver character count
// uint32_t byteKontUSART3 = 0;			//how many bytes must be read from USART6 so the data can be send to USART3



void USART3_init(void){
    
    /***************  PASOS A DAR
        1. Activar UART CLOCK y GPIO CLOCK
        2. Configurar los PINS como Alternate Functions
        3. Activar USART escribiendo en el bit UE en USART_CR1 un 1
        4. Programar el bit M de USART para definir los bits(word lenght)
        5. Seleccionar el baud rate deseado en USART_BRR
        6. Activar el transmisor/receptor usando los registros TE y RE de USART_CR1
    ****************/
    
    //1. Activar UART CLOCK
	
	RCC_APB1PeriphClockCmd(18);
    //2. Activar GPIO y Configurar los PINS como Alternate Functions
    
	USART_configure(GPIO_D, GPIO_PIN_8, GPIO_PIN_9, 7); //gpio, pin rx, pin tx, pin af

    //3. Activar USART escribiendo en el bit UE en USART_CR1 un 1
    
    USART_enable(OUR_USART3, ENABLE);

    //4. Programar el bit M de USART para definir los bits(word lenght)
    
    USART_setDataStopBits(OUR_USART3, UART_8_DATA_BITS, UART_1_STOP_BIT);
    
    //5. Seleccionar el baud rate deseado en USART_BRR
    
    USART_setBaudRate(OUR_USART3, BAUD_RATE_9600);

    //6. Activar el transmisor/receptor usando los registros TE y RE de USART_CR1
    
    USART_enableReciver(OUR_USART3, ENABLE);
    USART_enableTransmitter(OUR_USART3, ENABLE);
        
    //7. Activamos la posibilidad de interrumpir 
    
    RXNE_setStateInterrupt(OUR_USART3, ENABLE);
    
}

void USART_configure(GPIO_X GPIO, GPIO_PIN_X pinTX, GPIO_PIN_X pinRX, uint32_t pinAF)	//enable the clocks of the GPIOs that contain the RX and TX pins, configure them in alternate function at very high speed, do a generic conf of USART6 and enable the NVIC interrrupt
{
	
	GPIO_TypeDef* gpioType=GpioType(GPIO);

	RCC_AHB1PeriphClockCmd(GPIO);
	
	GPIO_initPinMode(gpioType, pinTX, MODE_AF); //usart6 tx
	GPIO_initPinMode(gpioType, pinRX, MODE_AF); //usart6 rx
	GPIO_setPinSpeed(gpioType, pinTX, VERY_HIGH_SPEED);
	GPIO_setPinSpeed(gpioType, pinRX, VERY_HIGH_SPEED);
	GPIO_setAFReg(gpioType, pinTX, pinAF); // referenceManual PAG 272 select an af
	GPIO_setAFReg(gpioType, pinRX, pinAF); // se usa para asignar el usart al mux, af7 = usart1-3, af8= usart4-6
	
	NVIC_enable(71);
}

void USART_sendString(OUR_USART_TypeDef* usart, char* string)		//this function copies the string introduced to the USART transmitter buffer, enables the TXE interrupt and sends the first character
{
			while (*string) {
				//sleep(1);	
				USART_sendChar(usart, *string);
				string++;
	}
}

void USART_sendChar(OUR_USART_TypeDef* usart, uint8_t c){
	
	while(!(usart->SR & (1<<7))); //esperamos a que TXE se setee --> cuando el buffer esta vacio
	usart->DR = c; //cargar los datos en el registro DR
}


char * USART_getString(void){
   
	static char cadena[200]; // array fijo para que no se llene la memoria
    //recibir una cadena de caracteres
	
    int i = 0;
    while(i < 200){
        cadena[i] = USART_getChar(OUR_USART3);
        if(cadena[i] == '\r'){
            cadena[i] = '\0';

            break;
        }
        i++;
    }
		return cadena;
	}

uint8_t USART_getChar (OUR_USART_TypeDef* usart){
            /*********** STEPS FOLLOWED *************
    
    1. Esperamos a que el bit RXNE se setee. Esto indica que la informacion se ha recibido y que se puede leer
    2. Leemos la informacion usando USART_DR.     Esto tambien limpia el bit RXNE
    
    ****************************************/

    uint8_t temp;
        
    while (!(usart->SR & OUR_UART_SR_RXNE));  // esperamos a que el bit RXNE se  --> se ha recibido la informaci?n
    temp = (uint8_t) usart->DR;  // leemos la informacion y limpiamos RXNE
    return temp;
}
