#include "my_RCC_and_GPIO.h"
#include "my_Systick.h"
#include "usartConfig.h"


void USART_enable(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable)
{
	if (enable)
	{
		usart->CR1 |= (1 << 13);
	}
	else
	{
		usart->CR1 &= ~(1u << 13);
	}
}

void USART_enableReciver(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable)
{
	if (enable)
	{
		usart->CR1 |= (1 << 2);
	}
	else
	{
		usart->CR1 &= ~(1u << 2);
	}
}

void USART_enableTransmitter(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable){
	if (enable)
	{
		usart->CR1 |= (1 << 3);
	}
	else
	{
		usart->CR1 &= ~(1u << 3);
	}
}


void USART_setDataStopBits(OUR_USART_TypeDef* usart, UART_DATA_BITS dataBits, UART_STOP_BITS stopBits)
{
	usart->CR1 &= ~((unsigned)dataBits  << 12); //ponemos 1 start bit, 8 data bits y n stop bits
    usart->CR2 &= ~((unsigned)stopBits << 12);	//ponemos 1 stop bit
}

void USART_setBaudRate(OUR_USART_TypeDef* usart, UART_BAUD_RATE desiredBaudRate)
{
	usart->BRR = getSysClockFreq() / desiredBaudRate;
}

void USART_setParity(OUR_USART_TypeDef* usart, UART_PARITY enable)
{
	if (enable)
	{
		usart->CR1 |= (1 << 9);
	}
	else
	{
		usart->CR1 &= ~(1u << 9);
	}
}

void USART_setParityControl(OUR_USART_TypeDef* usart, UART_PARITY_CONTROL enable)
{
	if (enable)
	{
		usart->CR1 |= (1 << 10);
	}
	else
	{
		usart->CR1 &= ~(1u << 10);
	}
}


void RXNE_setStateInterrupt(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable)
{
	if (enable)
	{
		usart->CR1 |= (1 << 5);
	}
	else
	{
		usart->CR1 &= ~(1u << 5);
	}
}

void TXE_setStateInterrupt(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable)
{
	if (enable)
	{
		usart->CR1 |= (1 << 7);
	}
	else
	{
		usart->CR1 &= ~(1u << 7);
	}
}

void TC_setStateInterrupt(OUR_USART_TypeDef* usart, UART_ENABLE_DISABLE enable)
{
	if (enable)
	{
		usart->CR1 |= (1 << 6);
	}
	else
	{
		usart->CR1 &= ~(1u << 6);
	}
}


void DR_setRegister(OUR_USART_TypeDef* usart, uint8_t enable)
{
	usart->DR = enable;
}

uint8_t DR_getRegisterValue(OUR_USART_TypeDef* usart)
{
	return (uint8_t)usart->DR;
}

uint32_t SR_getRegisterValue(OUR_USART_TypeDef* usart)
{
	return usart->SR;
}


void TC_clearInterrupt(OUR_USART_TypeDef* usart)
{
	usart->SR &= ~(0x01u << 6);
}

