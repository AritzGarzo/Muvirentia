//Ainhoa Alonso Antelo
#include "my_Systick.h"


void sleep(uint32_t milisegundos)
{
	if(milisegundos==0) return;
	uint32_t x = 0;
	uint32_t periodo_kopurua;
		// kalkulatu kontatu beharreko periodo kopurua

	uint32_t CPU_FREQ = getSysClockFreq();
	
	
	if ((milisegundos/1000)*CPU_FREQ > CPU_FREQ)
	{
		uint32_t segundos = milisegundos / 1000;

		uint32_t diferencia = milisegundos - segundos * 1000;
	
		if(diferencia != 0)
		{
			sleep(diferencia);
		}
		

		for (uint32_t i = 0; i < segundos; i++)
		{
			sleep(1000);
		}
	}
	else
	{

		periodo_kopurua = (CPU_FREQ / 1000) * milisegundos;
		SysTick->LOAD = periodo_kopurua - 1;

		SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_ENABLE_Msk;

		//ENABLE eta clkSource, Proggrammer's manual.pdf 4.5.1 atala


		do
		{

			if (SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk)
			{
				x = 1;
			}
			
		} while (x == 0); 
	}
}

void enableExternalClock(void){

	uint32_t reg=0;
	RCC->CR &= ~(0x01u<<18); //resetear HSEBypass
	RCC->CR |= 0x01<<16; //set hs on
	
	while (RCC->CR & RCC_CR_HSERDY_Msk){} //ESPERAR A QUE EL CLOCK SE ESTABILICE
		
		reg=RCC->CFGR;
		reg &= ~ RCC_CFGR_SW_Msk ;  //0x03;  
		reg |= RCC_CFGR_SW_HSE;   //0x01;
		RCC->CFGR=reg;
	
}



void disableExternalClock(void){

		RCC->CR &= ~(0x01u<<16); //set hs off

	RCC->CFGR &= ~ RCC_CFGR_SW_Msk; //me aseguro que el HSI esta puesto

}

void cambiarConfiguracionReloj(void){

	 uint32_t reg = RCC->CFGR;
  if(reg & 0x01){
    reg &=~ 0x03u;    // poner a 0
    reg |= RCC_CFGR_SW_HSI; //poner hsi
  } else {
    reg &=~ 0x03u; //poner a 0
    reg |= RCC_CFGR_SW_HSE; //habilitar hse
  }
  RCC->CFGR=reg;
	
}
uint32_t getSysClockFreq(void){
	uint32_t CPU_FREQ = 0;
	
  	if (RCC->CFGR & 0x01){
	
		CPU_FREQ =25000000u;
	}else{
		CPU_FREQ = 16000000u;
	}		
		return CPU_FREQ;//return value of clck frequency
}
